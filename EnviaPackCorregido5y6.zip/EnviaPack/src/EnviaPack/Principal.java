/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EnviaPack;

import java.time.LocalDate;
import javax.swing.JOptionPane;

/**
 *
 * @author camad
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          ListaPaquetes lista = new ListaPaquetes();
        PilaDinamica pila = new PilaDinamica();
        ColaPaquetes cola = new ColaPaquetes();
        ArbolDestinos arbol = new ArbolDestinos();
        ListaGuias guias = new ListaGuias();
        ListaDistribucion distribucion = new ListaDistribucion();

        int opcion = 0;

        do {
            try {
                String menu = "--- MENÚ ENVIAPACK ---\n"
                        + "1. Registrar ingreso de paquete (Lista)\n"
                        + "2. Apilar paquetes (Pila)\n"
                        + "3. Trasladar a cola de envío (Cola)\n"
                        + "4. Clasificar por destino (Árbol)\n"
                        + "5. Ver reporte final (Árbol Inorden)\n"
                        + "6. Generar guías de envío\n"
                        + "7. Ver guías\n"
                        + "8. Asignar distribución\n"
                        + "9. Ver distribución\n"
                        + "10. Salir\n"
                        + "Seleccione una opción:";

                opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

                switch (opcion) {

                    case 1:
                        Paquete nuevoP = new Paquete();
                        nuevoP.setDescripcion(JOptionPane.showInputDialog("Descripción del paquete:"));
                        nuevoP.setTipoEnvio(JOptionPane.showInputDialog("Tipo de envío:"));
                        nuevoP.setPeso(Double.parseDouble(JOptionPane.showInputDialog("Peso (kg):")));
                        lista.insertar(nuevoP);
                        JOptionPane.showMessageDialog(null, "Paquete registrado.");
                        break;

                    case 2:
                        if (lista.vacia()) {
                            JOptionPane.showMessageDialog(null, "Lista vacía.");
                        } else {
                            Nodo aux = lista.getInicio();
                            while (aux != null) {
                                pila.push(aux.getDato());
                                aux = aux.getSiguiente();
                            }
                            JOptionPane.showMessageDialog(null, "Paquetes apilados.");
                        }
                        break;

                    case 3:
                        if (pila.getCima() == null) {
                            JOptionPane.showMessageDialog(null, "Pila vacía.");
                        } else {
                            while (pila.getCima() != null) {
                                cola.encolar(pila.pop());
                            }
                            JOptionPane.showMessageDialog(null, "Enviados a cola.");
                        }
                        break;

                    case 4:
                        if (cola.vacia()) {
                            JOptionPane.showMessageDialog(null, "Cola vacía.");
                        } else {
                            while (!cola.vacia()) {
                                Paquete p = cola.desencolar();
                                String destino = JOptionPane.showInputDialog("Destino para: " + p.getDescripcion());
                                p.setDestino(destino);
                                arbol.insertar(p);
                            }
                            JOptionPane.showMessageDialog(null, "Clasificación completa.");
                        }
                        break;

                    case 5:
                        if (arbol.getRaiz() == null) {
                            JOptionPane.showMessageDialog(null, "Árbol vacío.");
                        } else {
                            System.out.println("=== REPORTE ===");
                            arbol.mostrarClasificacion(arbol.getRaiz());
                        }
                        break;

                    case 6:
                        if (arbol.getRaiz() == null) {
                            JOptionPane.showMessageDialog(null, "No hay paquetes clasificados.");
                        } else {
                            generarGuiasDesdeArbol(arbol.getRaiz(), guias);
                        }
                        break;

                    case 7:
                        guias.mostrar();
                        break;

                    case 8:
                        
                        guias.mostrar();
                        String codigo = JOptionPane.showInputDialog("Codigo guia:");
                        
                        String direccion = JOptionPane.showInputDialog("Dirección:");
                        String fechaTexto                               
                                = JOptionPane.showInputDialog("Ingrese la fecha de entrega estimada  (AAAA-MM-DD)):");
                        LocalDate fecha = LocalDate.parse(fechaTexto);
                        
                        String repartidor = JOptionPane.showInputDialog("Repartidor:");
                        String estado = JOptionPane.showInputDialog("Estado: ");
                        distribucion.asignarDistribucion(codigo, direccion, fecha, repartidor, estado);
                        break;

                    case 9:
                        distribucion.mostrar();
                        break;

                    case 10:
                        JOptionPane.showMessageDialog(null, "Saliendo...");
                        break;

                    default:
                        JOptionPane.showMessageDialog(null, "Opción inválida.");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error en los datos.");
            }

        } while (opcion != 10);
    }

    public static void generarGuiasDesdeArbol(NodoArbol nodo, ListaGuias guias) {
        if (nodo != null) {

            generarGuiasDesdeArbol(nodo.getIzquierda(), guias);

            Nodo aux = nodo.getLista().getInicio();
            while (aux != null) {
                guias.generarDesdePaquete(aux.getDato());
                aux = aux.getSiguiente();
            }

            generarGuiasDesdeArbol(nodo.getDerecha(), guias);
        }
        
        
        
    }
    
}
